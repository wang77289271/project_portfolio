import './Skills.scss'

const Skills = () => {
  return <div>Skills</div>
}

export default Skills
